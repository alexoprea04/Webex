package com.example.alertpush;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import com.example.alertpush.R;
import com.example.alertpush.MainActivity.alertPushClient;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

	public static final String EXTRA_MESSAGE = "message";
    public static final String PROPERTY_REG_ID = "registration_id";

	private WebView mWebView;    
    
    String SENDER_ID = "949077368972";

    static final String TAG = "GCMDemo";
    GoogleCloudMessaging gcm;

    Context context;
    String regid;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if(isNetworkConnected()){			    
			
				setContentView(R.layout.activity_main);		
				mWebView = (WebView) findViewById(R.id.webView1);
			    mWebView.loadUrl("http://192.168.12.207/Home/index");							   	
				mWebView.getSettings().setJavaScriptEnabled(true);		
				mWebView.setWebViewClient(new alertPushClient());
				mWebView.setWebChromeClient(new WebChromeClient());
	
		}
		
		context = getApplicationContext();
		gcm = GoogleCloudMessaging.getInstance(this);

				new RegisterBackground().execute();			
		}

	public class alertPushClient extends WebViewClient {
		
		public boolean shouldOverrideUrlLoading(WebView webview, String url)
		{	
			if(isNetworkConnected()){
					if (url.startsWith("tel:")) { 					
		                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));                     
		                startActivity(intent);
		            }else if(url.startsWith("mailto:")){             	
		            	Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);		            	
		            	String[] mail = Uri.parse(url).toString().split(":");
		            	intent.putExtra(Intent.EXTRA_EMAIL, new String[] {mail[1]});  
		            	intent.setType("plain/text");           	            	    
		            	startActivity(intent);             	
		            }else if(url.startsWith("http:") || url.startsWith("https:")) {
		            	  webview.loadUrl(url);
		            	  return true;
		              }
			}
			return true;
		}
		
        
	}	


	private boolean isNetworkConnected() {		
		  ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		  NetworkInfo ni = cm.getActiveNetworkInfo();
		  if (ni == null) return false;						   						  
		  else return true;		   
	}	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	protected void onResume(){
		super.onResume();

	}
	class RegisterBackground extends AsyncTask<String,String,String>{

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			String msg = "";
			try {
                if (gcm == null) {
                    gcm = GoogleCloudMessaging.getInstance(context);
                }
                regid = gcm.register(SENDER_ID);
                msg = "Dvice registered, registration ID=" + regid;
                Log.d("111", msg);
                sendRegistrationIdToBackend(regid);

            } catch (IOException ex) {
                msg = "Error :" + ex.getMessage();
            }
            return msg;
        }

		@Override
        protected void onPostExecute(String msg) {
            //mDisplay.append(msg + "\n");

        }
		
		
	private void sendRegistrationIdToBackend(String regid) {

		String url = "http://192.168.12.207/push.php";
		List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("regid", regid));
       DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);
        try {
			httpPost.setEntity(new UrlEncodedFormEntity(params));
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

        try {
			HttpResponse httpResponse = httpClient.execute(httpPost);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}         

}
}}